# Design Guidelines: AI Fake News Checker

## Design Approach
**Selected Approach:** Design System-Based with Material Design principles, drawing inspiration from fact-checking platforms like Snopes, FactCheck.org, and modern SaaS dashboards like Linear and Notion for clean information hierarchy.

**Rationale:** This utility-focused tool prioritizes credibility, clarity, and efficient information processing. Users need to quickly understand analysis results and make informed decisions, requiring a professional, trustworthy interface with strong information architecture.

## Typography

**Font Families:**
- Primary: Inter (Google Fonts) - for body text, UI elements, and data display
- Accent: Space Grotesk (Google Fonts) - for headings and emphasis

**Type Scale:**
- Hero/Page Titles: text-5xl font-bold (Space Grotesk)
- Section Headings: text-3xl font-semibold (Space Grotesk)
- Card Headers: text-xl font-semibold (Inter)
- Body Large: text-lg font-normal (Inter)
- Body: text-base font-normal (Inter)
- Captions/Metadata: text-sm font-medium (Inter)
- Labels: text-xs font-semibold uppercase tracking-wide (Inter)

## Layout System

**Spacing Primitives:** Tailwind units of 4, 6, 8, 12, 16, 24
- Component internal padding: p-6 or p-8
- Section spacing: py-16 or py-24
- Grid gaps: gap-6 or gap-8
- Card spacing: space-y-4 or space-y-6

**Container Strategy:**
- Main content: max-w-6xl mx-auto
- Input section: max-w-3xl mx-auto
- Analysis reports: max-w-5xl mx-auto

## Core Components

### Hero Section
**Layout:** Centered, focused design with immediate value proposition
- Headline emphasizing AI-powered verification
- Subheading explaining the tool's purpose
- Prominent URL input field with analyze button
- Trust indicators: "Powered by AI • Real-time Verification • Trusted Sources"
- No background image - clean, professional background treatment

### URL Input Interface
**Design:** Large, prominent input as the primary action
- Oversized input field (h-16) with rounded-xl borders
- Placeholder: "Paste article or social media post URL..."
- Icon prefix (link icon from Heroicons)
- Primary CTA button integrated into input (pill-shaped, h-12)
- Example links below input for quick testing
- Loading state with animated pulse indicator

### Credibility Score Display
**Visual Treatment:** Large, eye-catching score presentation
- Circular progress indicator (120px diameter) with percentage
- Score range labels beneath: "Low Risk" | "Moderate" | "High Risk"
- Animated fill on load
- Supporting metrics in grid: Source Reliability, Fact Accuracy, Bias Detection

### Analysis Report Cards
**Structure:** Modular card system for different analysis components
- Rounded-2xl cards with substantial padding (p-8)
- Shadow-lg for depth
- Each card contains: icon header, title, content, and action area

**Card Types:**
1. **Claim Verification Card**
   - List of extracted claims (max 5 visible)
   - Each claim shows: statement, verification status icon, brief explanation
   - Expandable details for sources

2. **Source Analysis Card**
   - Publisher information with reliability badge
   - Domain age and reputation score
   - Known bias indicators
   - Historical accuracy record

3. **Content Analysis Card**
   - Sentiment analysis visualization
   - Emotional language detection
   - Clickbait indicators
   - Writing quality assessment

4. **Cross-Reference Card**
   - Related articles from trusted sources
   - Supporting/contradicting evidence
   - Expert commentary when available

### Navigation
**Layout:** Clean header with focused navigation
- Logo/brand left aligned
- Navigation items: How It Works, About, API
- CTA button: "Try Demo" (right aligned)
- Sticky header on scroll with shadow transition

### Footer
**Design:** Information-rich, multi-column layout
- 4 columns on desktop, stacked on mobile
- Column 1: Brand + mission statement
- Column 2: Product (How It Works, Methodology, Accuracy)
- Column 3: Resources (Blog, Research, Guidelines)
- Column 4: Contact + Social links
- Bottom bar with copyright, privacy policy, terms
- Newsletter signup with inline form

## Page Sections (Landing Page)

### How It Works Section
**Layout:** 3-column grid showcasing process
- Step 1: Paste URL (with input icon visualization)
- Step 2: AI Analysis (with processing animation icon)
- Step 3: Get Report (with report preview icon)
- Each step has number badge, title, description

### Features Grid
**Layout:** 2x2 grid on desktop, stacked on mobile
- Real-time Verification (with speed icon)
- Multi-source Cross-checking (with sources icon)
- Credibility Scoring (with gauge icon)
- Detailed Reports (with document icon)
- Each feature: large icon (w-12 h-12), title, 2-line description

### Trust & Credibility Section
**Design:** Stats showcase with social proof
- 3-column stat display: "10M+ Articles Analyzed" | "95% Accuracy Rate" | "50K+ Daily Users"
- Large numbers (text-5xl font-bold)
- Supporting text below each stat
- Logos of trusted news organizations (placeholder references)

### Methodology Section
**Layout:** Alternating text-image blocks
- Explains AI technology used
- Details fact-checking process
- Shows example analysis
- Transparency about limitations

### CTA Section
**Design:** Full-width call-to-action
- Centered content (max-w-3xl)
- Compelling headline: "Start Verifying News Today"
- Subtext about free access
- Duplicate URL input field
- Supporting text: "No signup required • Instant results"

## Icons
**Library:** Heroicons (CDN)
**Usage:**
- CheckCircleIcon (verified claims)
- XCircleIcon (false claims)
- ExclamationTriangleIcon (questionable content)
- ShieldCheckIcon (trusted sources)
- MagnifyingGlassIcon (analysis)
- LinkIcon (URL input)
- ChartBarIcon (credibility metrics)

## Animations
**Minimal, purposeful animations only:**
- Score counter animation (counting up to final score)
- Progress circle fill animation
- Card fade-in on scroll (stagger by 100ms)
- Loading spinner for analysis in progress
- Smooth transitions on hover states (150ms)

## Responsive Behavior
**Breakpoints:**
- Mobile: Single column, stacked cards, full-width inputs
- Tablet (md:): 2-column grids, expanded cards
- Desktop (lg:): Full multi-column layouts, optimal spacing

**Mobile Optimizations:**
- Simplified credibility score (smaller circular indicator)
- Collapsible analysis sections
- Sticky CTA button at bottom
- Reduced padding (p-4 instead of p-8)

## Images
**No hero image** - This tool prioritizes functionality and trust over visual flourish. The hero section uses clean background treatment with focus on the input interface.

**Supporting Images:**
- Methodology section: Diagram illustrations showing AI analysis process (simple, schematic style)
- How It Works: Icon-based visualizations rather than photographs
- Trust section: Logos of news organizations (vector format, monochrome)
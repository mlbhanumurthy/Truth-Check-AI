import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import Header from "@/components/Header";
import CredibilityScore from "@/components/CredibilityScore";
import ClaimVerificationCard from "@/components/ClaimVerificationCard";
import SourceAnalysisCard from "@/components/SourceAnalysisCard";
import ContentAnalysisCard from "@/components/ContentAnalysisCard";
import Footer from "@/components/Footer";

export default function AnalysisResults() {
  const mockClaims = [
    {
      id: "1",
      statement: "The unemployment rate has dropped to its lowest level in 50 years",
      status: "verified" as const,
      explanation: "According to Bureau of Labor Statistics data from Q3 2024, the unemployment rate is at 3.5%, matching the lowest levels since 1969.",
      sources: ["Bureau of Labor Statistics - bls.gov", "Reuters - reuters.com/economy"]
    },
    {
      id: "2",
      statement: "Scientists have discovered a cure for all types of cancer",
      status: "false" as const,
      explanation: "No credible scientific sources support this claim. While progress has been made in cancer treatment, no universal cure exists.",
      sources: ["National Cancer Institute - cancer.gov", "World Health Organization - who.int"]
    },
    {
      id: "3",
      statement: "The stock market reached record highs this month",
      status: "verified" as const,
      explanation: "Multiple financial indices including S&P 500 and NASDAQ reached all-time highs on October 15, 2024.",
      sources: ["Bloomberg - bloomberg.com/markets", "Financial Times - ft.com"]
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="max-w-5xl mx-auto space-y-8">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="sm" data-testid="button-back">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
              </Link>
            </div>

            <div className="space-y-4">
              <h1 className="text-4xl font-bold">Analysis Results</h1>
              <p className="text-muted-foreground" data-testid="text-analyzed-url">
                Analyzed: https://example.com/breaking-news-article
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1">
                <CredibilityScore
                  score={72}
                  sourceReliability={85}
                  factAccuracy={68}
                  biasDetection={62}
                />
              </div>

              <div className="lg:col-span-2 space-y-6">
                <ClaimVerificationCard claims={mockClaims} />
                <SourceAnalysisCard
                  publisher="The New York Times"
                  domain="nytimes.com"
                  reliability={88}
                  domainAge="Established 1996"
                  bias="Center-Left"
                  accuracyRecord={92}
                />
                <ContentAnalysisCard
                  sentiment="neutral"
                  emotionalLanguage={45}
                  clickbaitScore={32}
                  writingQuality={78}
                />
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

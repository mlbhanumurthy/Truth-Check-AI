import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, AlertTriangle, XCircle } from "lucide-react";

interface CredibilityScoreProps {
  score: number;
  sourceReliability: number;
  factAccuracy: number;
  biasDetection: number;
}

export default function CredibilityScore({ 
  score, 
  sourceReliability, 
  factAccuracy, 
  biasDetection 
}: CredibilityScoreProps) {
  const getScoreColor = (score: number) => {
    if (score >= 70) return "text-green-600";
    if (score >= 40) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreLabel = (score: number) => {
    if (score >= 70) return { text: "Low Risk", icon: CheckCircle2, color: "bg-green-100 text-green-700 border-green-200" };
    if (score >= 40) return { text: "Moderate Risk", icon: AlertTriangle, color: "bg-yellow-100 text-yellow-700 border-yellow-200" };
    return { text: "High Risk", icon: XCircle, color: "bg-red-100 text-red-700 border-red-200" };
  };

  const scoreLabel = getScoreLabel(score);
  const ScoreIcon = scoreLabel.icon;

  return (
    <Card className="p-8">
      <div className="flex flex-col items-center space-y-6">
        <div className="relative">
          <svg className="w-32 h-32 transform -rotate-90">
            <circle
              cx="64"
              cy="64"
              r="56"
              stroke="currentColor"
              strokeWidth="8"
              fill="none"
              className="text-muted"
            />
            <circle
              cx="64"
              cy="64"
              r="56"
              stroke="currentColor"
              strokeWidth="8"
              fill="none"
              strokeDasharray={`${(score / 100) * 351.86} 351.86`}
              className={getScoreColor(score)}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className={`text-4xl font-bold ${getScoreColor(score)}`} data-testid="text-credibility-score">
                {score}
              </div>
              <div className="text-xs text-muted-foreground">/ 100</div>
            </div>
          </div>
        </div>

        <Badge variant="outline" className={`${scoreLabel.color} border`}>
          <ScoreIcon className="h-3.5 w-3.5 mr-1.5" />
          {scoreLabel.text}
        </Badge>

        <div className="w-full grid grid-cols-3 gap-4 pt-4 border-t">
          <div className="text-center space-y-1">
            <div className="text-2xl font-semibold" data-testid="text-source-reliability">
              {sourceReliability}%
            </div>
            <div className="text-xs text-muted-foreground">Source Reliability</div>
          </div>
          <div className="text-center space-y-1">
            <div className="text-2xl font-semibold" data-testid="text-fact-accuracy">
              {factAccuracy}%
            </div>
            <div className="text-xs text-muted-foreground">Fact Accuracy</div>
          </div>
          <div className="text-center space-y-1">
            <div className="text-2xl font-semibold" data-testid="text-bias-detection">
              {biasDetection}%
            </div>
            <div className="text-xs text-muted-foreground">Bias Detection</div>
          </div>
        </div>
      </div>
    </Card>
  );
}

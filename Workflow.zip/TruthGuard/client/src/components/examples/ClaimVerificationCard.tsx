import ClaimVerificationCard from '../ClaimVerificationCard';

export default function ClaimVerificationCardExample() {
  const mockClaims = [
    {
      id: "1",
      statement: "The unemployment rate has dropped to its lowest level in 50 years",
      status: "verified" as const,
      explanation: "According to Bureau of Labor Statistics data from Q3 2024, the unemployment rate is at 3.5%, matching the lowest levels since 1969.",
      sources: ["Bureau of Labor Statistics", "Reuters"]
    },
    {
      id: "2",
      statement: "Scientists have discovered a cure for all types of cancer",
      status: "false" as const,
      explanation: "No credible scientific sources support this claim. While progress has been made in cancer treatment, no universal cure exists.",
      sources: ["National Cancer Institute", "WHO"]
    }
  ];

  return (
    <div className="p-8">
      <ClaimVerificationCard claims={mockClaims} />
    </div>
  );
}

import HowItWorksSection from '../HowItWorksSection';

export default function HowItWorksSectionExample() {
  return <HowItWorksSection />;
}

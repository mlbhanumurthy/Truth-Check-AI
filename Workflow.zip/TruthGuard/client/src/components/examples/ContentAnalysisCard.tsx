import ContentAnalysisCard from '../ContentAnalysisCard';

export default function ContentAnalysisCardExample() {
  return (
    <div className="p-8">
      <ContentAnalysisCard
        sentiment="neutral"
        emotionalLanguage={45}
        clickbaitScore={32}
        writingQuality={78}
      />
    </div>
  );
}

import SourceAnalysisCard from '../SourceAnalysisCard';

export default function SourceAnalysisCardExample() {
  return (
    <div className="p-8">
      <SourceAnalysisCard
        publisher="The New York Times"
        domain="nytimes.com"
        reliability={88}
        domainAge="Established 1996"
        bias="Center-Left"
        accuracyRecord={92}
      />
    </div>
  );
}

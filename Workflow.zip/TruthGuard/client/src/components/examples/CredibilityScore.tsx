import CredibilityScore from '../CredibilityScore';

export default function CredibilityScoreExample() {
  return (
    <div className="p-8">
      <CredibilityScore 
        score={72} 
        sourceReliability={85} 
        factAccuracy={68} 
        biasDetection={62} 
      />
    </div>
  );
}

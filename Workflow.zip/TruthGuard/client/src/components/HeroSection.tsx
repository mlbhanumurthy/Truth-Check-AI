import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link2, Sparkles } from "lucide-react";

export default function HeroSection() {
  const [url, setUrl] = useState("");

  const handleAnalyze = () => {
    console.log("Analyzing URL:", url);
  };

  return (
    <section className="w-full py-24 md:py-32 lg:py-40">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center text-center space-y-8 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="font-medium text-primary">AI-Powered Verification</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight">
            Stop Fake News in Its Tracks
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl">
            Verify the authenticity of any article or social media post instantly. 
            Our AI analyzes content, cross-checks facts, and provides credibility scores 
            backed by trusted sources.
          </p>

          <div className="w-full max-w-2xl space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Link2 className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  type="url"
                  placeholder="Paste article or social media post URL..."
                  className="h-14 pl-12 pr-4 text-base rounded-xl"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  data-testid="input-url"
                />
              </div>
              <Button 
                size="lg" 
                className="h-14 px-8 rounded-xl"
                onClick={handleAnalyze}
                data-testid="button-analyze"
              >
                Analyze Now
              </Button>
            </div>
            
            <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Powered by AI
              </span>
              <span className="flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Real-time Verification
              </span>
              <span className="flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Trusted Sources
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

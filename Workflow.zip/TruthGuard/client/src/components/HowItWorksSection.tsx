import { Card } from "@/components/ui/card";
import { Link2, Cpu, FileText } from "lucide-react";

export default function HowItWorksSection() {
  const steps = [
    {
      number: 1,
      icon: Link2,
      title: "Paste URL",
      description: "Copy and paste the link to any article or social media post you want to verify"
    },
    {
      number: 2,
      icon: Cpu,
      title: "AI Analysis",
      description: "Our AI analyzes the content, checks facts against trusted sources, and detects patterns"
    },
    {
      number: 3,
      icon: FileText,
      title: "Get Report",
      description: "Receive a detailed credibility report with scores, verified claims, and references"
    }
  ];

  return (
    <section id="how-it-works" className="w-full py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold">How It Works</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Three simple steps to verify any news article or social media post
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {steps.map((step) => (
            <Card key={step.number} className="p-8 text-center space-y-4 hover-elevate" data-testid={`card-step-${step.number}`}>
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-2">
                <step.icon className="h-8 w-8 text-primary" />
              </div>
              <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold">
                {step.number}
              </div>
              <h3 className="text-xl font-semibold">{step.title}</h3>
              <p className="text-muted-foreground">{step.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

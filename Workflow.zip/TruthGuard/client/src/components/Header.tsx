import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Shield } from "lucide-react";

export default function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/">
          <div className="flex items-center gap-2 hover-elevate active-elevate-2 rounded-md px-3 py-2 -ml-3 cursor-pointer" data-testid="link-home">
            <Shield className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">TruthCheck AI</span>
          </div>
        </Link>
        
        <nav className="hidden md:flex items-center gap-6">
          <Link href="#how-it-works">
            <a className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-how-it-works">
              How It Works
            </a>
          </Link>
          <Link href="#features">
            <a className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-features">
              Features
            </a>
          </Link>
          <Link href="#about">
            <a className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-about">
              About
            </a>
          </Link>
        </nav>

        <Button size="default" data-testid="button-try-demo">
          Try Demo
        </Button>
      </div>
    </header>
  );
}

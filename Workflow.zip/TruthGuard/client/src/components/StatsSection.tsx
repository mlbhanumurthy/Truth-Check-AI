export default function StatsSection() {
  const stats = [
    {
      value: "10M+",
      label: "Articles Analyzed"
    },
    {
      value: "95%",
      label: "Accuracy Rate"
    },
    {
      value: "50K+",
      label: "Daily Users"
    }
  ];

  return (
    <section className="w-full py-24 bg-primary text-primary-foreground">
      <div className="container px-4 md:px-6">
        <div className="grid md:grid-cols-3 gap-12 text-center">
          {stats.map((stat, index) => (
            <div key={index} className="space-y-2" data-testid={`stat-${index}`}>
              <div className="text-5xl md:text-6xl font-bold">{stat.value}</div>
              <div className="text-lg opacity-90">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, TrendingUp, AlertTriangle } from "lucide-react";

interface SourceAnalysisCardProps {
  publisher: string;
  domain: string;
  reliability: number;
  domainAge: string;
  bias: string;
  accuracyRecord: number;
}

export default function SourceAnalysisCard({
  publisher,
  domain,
  reliability,
  domainAge,
  bias,
  accuracyRecord
}: SourceAnalysisCardProps) {
  const getReliabilityBadge = (score: number) => {
    if (score >= 80) return <Badge className="bg-green-100 text-green-700 border-green-200">High Reliability</Badge>;
    if (score >= 50) return <Badge className="bg-yellow-100 text-yellow-700 border-yellow-200">Moderate Reliability</Badge>;
    return <Badge className="bg-red-100 text-red-700 border-red-200">Low Reliability</Badge>;
  };

  return (
    <Card className="p-8">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <ShieldCheck className="h-6 w-6 text-primary" />
          <h3 className="text-xl font-semibold">Source Analysis</h3>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Publisher</span>
              <span className="text-sm text-foreground font-semibold" data-testid="text-publisher">
                {publisher}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Domain</span>
              <span className="text-sm text-muted-foreground" data-testid="text-domain">
                {domain}
              </span>
            </div>
          </div>

          <div className="border-t pt-4 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Reliability Score</span>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold" data-testid="text-reliability">
                  {reliability}%
                </span>
                {getReliabilityBadge(reliability)}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Domain Age</span>
              <span className="text-sm text-muted-foreground" data-testid="text-domain-age">
                {domainAge}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Detected Bias</span>
              <Badge variant="outline" data-testid="text-bias">
                {bias}
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Historical Accuracy</span>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <span className="text-sm font-semibold text-green-600" data-testid="text-accuracy">
                  {accuracyRecord}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

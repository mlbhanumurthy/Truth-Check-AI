import { Link } from "wouter";
import { Shield } from "lucide-react";
import { SiGithub, SiX, SiLinkedin } from "react-icons/si";

export default function Footer() {
  return (
    <footer className="w-full border-t bg-background">
      <div className="container px-4 md:px-6 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="space-y-4">
            <Link href="/">
              <a className="flex items-center gap-2">
                <Shield className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">TruthCheck AI</span>
              </a>
            </Link>
            <p className="text-sm text-muted-foreground">
              Fighting misinformation with AI-powered fact-checking technology
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-semibold">Product</h4>
            <nav className="flex flex-col space-y-2">
              <Link href="#how-it-works">
                <a className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  How It Works
                </a>
              </Link>
              <Link href="#features">
                <a className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Features
                </a>
              </Link>
              <Link href="#methodology">
                <a className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Methodology
                </a>
              </Link>
            </nav>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-semibold">Resources</h4>
            <nav className="flex flex-col space-y-2">
              <Link href="#blog">
                <a className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Blog
                </a>
              </Link>
              <Link href="#research">
                <a className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Research
                </a>
              </Link>
              <Link href="#guidelines">
                <a className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Guidelines
                </a>
              </Link>
            </nav>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-semibold">Connect</h4>
            <div className="flex gap-4">
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" aria-label="GitHub">
                <SiGithub className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" aria-label="X">
                <SiX className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" aria-label="LinkedIn">
                <SiLinkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © 2024 TruthCheck AI. All rights reserved.
          </p>
          <nav className="flex gap-6">
            <Link href="#privacy">
              <a className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Privacy Policy
              </a>
            </Link>
            <Link href="#terms">
              <a className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Terms of Service
              </a>
            </Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}

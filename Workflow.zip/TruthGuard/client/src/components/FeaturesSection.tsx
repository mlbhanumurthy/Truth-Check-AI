import { Card } from "@/components/ui/card";
import { Zap, Globe, Gauge, FileCheck } from "lucide-react";

export default function FeaturesSection() {
  const features = [
    {
      icon: Zap,
      title: "Real-time Verification",
      description: "Get instant analysis results powered by the latest AI technology"
    },
    {
      icon: Globe,
      title: "Multi-source Cross-checking",
      description: "We verify claims against multiple trusted news sources and databases"
    },
    {
      icon: Gauge,
      title: "Credibility Scoring",
      description: "Easy-to-understand scores help you quickly assess article reliability"
    },
    {
      icon: FileCheck,
      title: "Detailed Reports",
      description: "Comprehensive breakdowns with source citations and claim verification"
    }
  ];

  return (
    <section id="features" className="w-full py-24">
      <div className="container px-4 md:px-6">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold">Powerful Features</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to combat misinformation and verify news sources
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {features.map((feature, index) => (
            <Card key={index} className="p-8 space-y-4 hover-elevate" data-testid={`card-feature-${index}`}>
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10">
                <feature.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link2 } from "lucide-react";

export default function CTASection() {
  const [url, setUrl] = useState("");

  const handleAnalyze = () => {
    console.log("Analyzing URL:", url);
  };

  return (
    <section className="w-full py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold">
              Start Verifying News Today
            </h2>
            <p className="text-lg text-muted-foreground">
              Join thousands of users who trust TruthCheck AI to combat misinformation
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto">
            <div className="relative flex-1">
              <Link2 className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="url"
                placeholder="Paste article or social media post URL..."
                className="h-14 pl-12 pr-4 text-base rounded-xl"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                data-testid="input-cta-url"
              />
            </div>
            <Button 
              size="lg" 
              className="h-14 px-8 rounded-xl"
              onClick={handleAnalyze}
              data-testid="button-cta-analyze"
            >
              Analyze Now
            </Button>
          </div>

          <p className="text-sm text-muted-foreground">
            No signup required • Instant results
          </p>
        </div>
      </div>
    </section>
  );
}

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, AlertCircle, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";

interface Claim {
  id: string;
  statement: string;
  status: "verified" | "false" | "unverified";
  explanation: string;
  sources: string[];
}

interface ClaimVerificationCardProps {
  claims: Claim[];
}

export default function ClaimVerificationCard({ claims }: ClaimVerificationCardProps) {
  const [expandedClaim, setExpandedClaim] = useState<string | null>(null);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "verified":
        return <CheckCircle2 className="h-5 w-5 text-green-600" />;
      case "false":
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return <AlertCircle className="h-5 w-5 text-yellow-600" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "verified":
        return <Badge className="bg-green-100 text-green-700 border-green-200">Verified</Badge>;
      case "false":
        return <Badge className="bg-red-100 text-red-700 border-red-200">False</Badge>;
      default:
        return <Badge className="bg-yellow-100 text-yellow-700 border-yellow-200">Unverified</Badge>;
    }
  };

  return (
    <Card className="p-8">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <CheckCircle2 className="h-6 w-6 text-primary" />
          <h3 className="text-xl font-semibold">Claim Verification</h3>
        </div>

        <div className="space-y-4">
          {claims.map((claim) => (
            <div
              key={claim.id}
              className="border rounded-lg p-4 space-y-3 hover-elevate"
              data-testid={`claim-${claim.id}`}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">{getStatusIcon(claim.status)}</div>
                <div className="flex-1 space-y-2">
                  <p className="font-medium text-sm">{claim.statement}</p>
                  {getStatusBadge(claim.status)}
                </div>
              </div>

              {expandedClaim === claim.id && (
                <div className="pl-8 pt-2 space-y-3 border-t">
                  <p className="text-sm text-muted-foreground">{claim.explanation}</p>
                  {claim.sources.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                        Sources:
                      </p>
                      {claim.sources.map((source, idx) => (
                        <p key={idx} className="text-xs text-primary hover:underline cursor-pointer">
                          {source}
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <Button
                variant="ghost"
                size="sm"
                className="w-full"
                onClick={() => setExpandedClaim(expandedClaim === claim.id ? null : claim.id)}
                data-testid={`button-toggle-claim-${claim.id}`}
              >
                {expandedClaim === claim.id ? (
                  <>
                    <ChevronUp className="h-4 w-4 mr-1" />
                    Hide Details
                  </>
                ) : (
                  <>
                    <ChevronDown className="h-4 w-4 mr-1" />
                    Show Details
                  </>
                )}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}

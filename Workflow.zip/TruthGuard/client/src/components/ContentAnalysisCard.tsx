import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BarChart3, Heart, AlertCircle, CheckCircle2 } from "lucide-react";

interface ContentAnalysisCardProps {
  sentiment: "positive" | "neutral" | "negative";
  emotionalLanguage: number;
  clickbaitScore: number;
  writingQuality: number;
}

export default function ContentAnalysisCard({
  sentiment,
  emotionalLanguage,
  clickbaitScore,
  writingQuality
}: ContentAnalysisCardProps) {
  const getSentimentBadge = (sentiment: string) => {
    switch (sentiment) {
      case "positive":
        return <Badge className="bg-green-100 text-green-700 border-green-200">Positive</Badge>;
      case "negative":
        return <Badge className="bg-red-100 text-red-700 border-red-200">Negative</Badge>;
      default:
        return <Badge className="bg-blue-100 text-blue-700 border-blue-200">Neutral</Badge>;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 70) return "text-red-600";
    if (score >= 40) return "text-yellow-600";
    return "text-green-600";
  };

  return (
    <Card className="p-8">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <BarChart3 className="h-6 w-6 text-primary" />
          <h3 className="text-xl font-semibold">Content Analysis</h3>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Sentiment</span>
            {getSentimentBadge(sentiment)}
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Emotional Language</span>
              <span className="text-sm font-semibold" data-testid="text-emotional-language">
                {emotionalLanguage}%
              </span>
            </div>
            <Progress value={emotionalLanguage} className="h-2" />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Clickbait Indicators</span>
                {clickbaitScore > 60 && <AlertCircle className="h-4 w-4 text-yellow-600" />}
              </div>
              <span className={`text-sm font-semibold ${getScoreColor(clickbaitScore)}`} data-testid="text-clickbait">
                {clickbaitScore}%
              </span>
            </div>
            <Progress value={clickbaitScore} className="h-2" />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Writing Quality</span>
                {writingQuality >= 70 && <CheckCircle2 className="h-4 w-4 text-green-600" />}
              </div>
              <span className="text-sm font-semibold text-green-600" data-testid="text-writing-quality">
                {writingQuality}%
              </span>
            </div>
            <Progress value={writingQuality} className="h-2" />
          </div>
        </div>
      </div>
    </Card>
  );
}
